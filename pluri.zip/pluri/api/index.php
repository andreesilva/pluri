<?php
ini_set("display_errors",1);

require 'Slim/Slim.php';

\Slim\Slim::registerAutoloader();

$app = new \Slim\Slim();
$app->response()->header('Content-Type', 'application/json;charset=utf-8');



$app->get('/saldo_estoque', function() use ($app) {
		$sql_query = "SELECT * FROM tbl_produtos";
    
	    try {
			$dbCon = conexao();
			$stmt   = $dbCon->query($sql_query);
			$users  = $stmt->fetchAll(PDO::FETCH_OBJ);
			$dbCon = null;
			echo '{"produtos": ' . json_encode($users) . '}';
		}
		catch(\Exception $e) {
			echo '{"error":{"text":'. $e->getMessage() .'}}';
		}	
});



function conexao() {
    try {
        $conn = new PDO("mysql:host=dev-homologacao.ctpetlcg3bwb.us-east-1.rds.amazonaws.com;dbname=bd_teste_estoque;charset=utf8", "teste_estoque", "h3t4tgfh",array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch(PDOException $e) {
        echo 'ERROR: ' . $e->getMessage();
    }
    return $conn;
}



$app->run();
?>